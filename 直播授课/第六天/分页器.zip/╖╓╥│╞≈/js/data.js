define(function () {
    var index = 0;
    return [{
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }, {
        ID: ++index,
        module: "模块" + index,
        info: "信息" + index,
        time: "2016-07-02",
    }]
})